def print_name(name):
    print(f'merhaba {name} nasılsın ?')