from isim import print_name

print_name('bedir')